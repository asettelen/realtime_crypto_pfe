dirname=$(dirname $0)

source "${dirname}"/delete_gke_cluster.sh

source "${dirname}"/delete_pubsub_topic.sh

 
