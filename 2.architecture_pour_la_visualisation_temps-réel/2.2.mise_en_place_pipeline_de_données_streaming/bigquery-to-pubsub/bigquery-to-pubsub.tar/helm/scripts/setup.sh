dirname=$(dirname $0)

source "${dirname}"/create_gke_cluster.sh

source "${dirname}"/create_temp_resources.sh

source "${dirname}"/create_pubsub_topic.sh

 
