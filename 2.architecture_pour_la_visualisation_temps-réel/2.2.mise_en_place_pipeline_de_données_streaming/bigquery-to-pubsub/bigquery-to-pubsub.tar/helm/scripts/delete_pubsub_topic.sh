TOPIC_NAME=bigquery-to-pubsub-0
gcloud pubsub topics delete ${TOPIC_NAME}
